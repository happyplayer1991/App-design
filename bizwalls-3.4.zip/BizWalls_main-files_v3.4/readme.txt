BizWalls is a Responsive Multipurpose VOIP & Virtual Phone Business WordPress Theme designed for All kinds of VOIP Business. It's also support VOIP Pricing Calculator and Virtual Phone Number Pricing Selling Form Plugin. Anyone can easily update/edit this plugin to follow our Well Sorted Documentation.


==========================================================================
Well Sorted Documentation included in "main_files/documentation" (folder).
==========================================================================

=========================================================
Changelog included in "documentation/changelog" (folder).
=========================================================


SOURCE AND CREADITS:
====================

Photos:

    All 'images' used on the demo site is for demonstration purposes only and are not included in the main download file.

Fonts Used:

    Google Fonts (Raleway) - http://www.google.com/webfonts
    Font Awesome - http://fontawesome.io/

Frameworks / Libraries:

    reduxframework - https://reduxframework.com/
    CMB2 - https://wordpress.org/plugins/cmb2/

    jQuery - https://jquery.com/
    Twitter Bootstrap - http://getbootstrap.com

Plugins Used:

    Contact Form 7 - https://wordpress.org/plugins/contact-form-7/

    Waypoints - https://github.com/imakewebthings/waypoints/
    jQuery CounterUP - https://github.com/bfintal/Counter-Up
    Owl Carousel - https://github.com/OwlFonk/OwlCarousel
    jquery ajaxchimp - https://github.com/scdoshi/jquery-ajaxchimp